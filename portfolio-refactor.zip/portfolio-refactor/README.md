# CASTAR Portfolio — refactored

## Folder structure

```
src/
  data/content.json          <- ALL editable content lives here (nav, bio, projects, skills, contact, experience)
  types.ts                   <- TypeScript shapes matching content.json
  theme/theme.ts              <- colors, header height, connector length — edit once, applies everywhere
  styles/fonts.css            <- Roboto Thin @font-face
  hooks/useScrollSections.ts  <- pinned-scroll tracking logic (active page + continuous progress)
  components/
    Background.tsx            <- site-wide background wrapper (swap this file to re-theme the background later)
    Header.tsx                 <- top nav, flat links, no hamburger
    Rail.tsx / RailNode.tsx    <- the vertical timeline on the left
    ProgressBar.tsx            <- continuous progress bar (does not reset per page)
    ProjectRow.tsx / SocialButton.tsx
    pages/
      SummaryPage.tsx
      AboutPage.tsx           <- bio + education + experience
      ProjectsPage.tsx
      SkillsPage.tsx
      ContactPage.tsx
  Portfolio.tsx                <- assembles everything
fonts/
  Roboto-Thin.ttf              <- ADD YOUR ACTUAL FONT FILE HERE (see below)
```

## Setup

```bash
npm i react-icons
```

Copy `src/` and `fonts/` into your project (Vite/Next/CRA — any React + Tailwind setup works).

### Font
Place your real `Roboto-Thin.ttf` file inside `src/fonts/`. `styles/fonts.css` already
points to it. Until you add the file, add this to your `index.html` `<head>` as a
visual fallback at the same weight:

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100&display=swap" rel="stylesheet">
```

And import the stylesheet once in your app entry point:
```ts
import "./styles/fonts.css";
```

### Your photo
Put your photo at `public/images/avatar.jpg` (path already referenced in
`content.json` → `profile.avatar`). If the file isn't found yet, a placeholder
shows automatically so nothing breaks.

### TypeScript + JSON imports
If your `tsconfig.json` doesn't already have this, add it so `content.json`
can be imported directly:
```json
{
  "compilerOptions": {
    "resolveJsonModule": true,
    "esModuleInterop": true
  }
}
```

## Updating content
Open `src/data/content.json` — every page reads from here. Add a project,
edit your bio, add an experience entry, change contact info — no component
code needs to change.

## Updating the theme
Open `src/theme/theme.ts` — every component reads colors from `theme`, so
changing a hex value there updates the whole site.

## What changed in this refactor
- Content extracted from component code into `data/content.json`.
- Code split into `data/`, `theme/`, `styles/`, `hooks/`, `components/`, `components/pages/`.
- `Background.tsx` isolates the site-wide background so it can change later
  without touching page logic.
- Header: hamburger menu removed entirely; nav links are always laid out
  flat on the right, on every screen size.
- Mobile now uses the SAME pinned/sticky scroll pattern as desktop (previously
  it fell back to a plain stacked layout). The rail just becomes much
  narrower, and the hero node swaps its photo for a Home icon on small
  screens, so the content card can use nearly the full width.
- Progress bar is continuous across all 5 pages (0–100% for the whole
  scroll journey) instead of resetting back to 0% at the start of each page.
- Added an "About" page (bio + education + experience) — a page dedicated
  to the fuller resume-style detail, separate from the short Summary/hero.
