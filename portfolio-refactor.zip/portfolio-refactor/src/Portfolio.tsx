/**
 * Portfolio.tsx
 *
 * Assembles the site: Background wraps everything, Header sits on top,
 * a pinned/sticky scroll area holds the Rail (timeline) + content card.
 * The SAME pinned pattern runs on every screen size now — mobile just
 * gets a much narrower rail (see Rail.tsx) so the content card can use
 * almost the full width.
 *
 * All copy lives in src/data/content.json — update that file, not this one.
 */

import Background from "./components/Background";
import Header from "./components/Header";
import Rail from "./components/Rail";
import ProgressBar from "./components/ProgressBar";
import SummaryPage from "./components/pages/SummaryPage";
import AboutPage from "./components/pages/AboutPage";
import ProjectsPage from "./components/pages/ProjectsPage";
import SkillsPage from "./components/pages/SkillsPage";
import ContactPage from "./components/pages/ContactPage";
import { useScrollSections } from "./hooks/useScrollSections";
import { theme } from "./theme/theme";
import content from "./data/content.json";
import type { ContentData } from "./types";

// Cast: content.json's `status` fields are plain strings from JSON; this
// tells TS to trust they match the ProjectStatus union (they do, since we
// control the JSON). If you add a new status value, update types.ts too.
const data = content as unknown as ContentData;

const ZONE_COUNT = data.nav.length; // 5: summary, about, projects, skills, contact

export default function Portfolio() {
  const { wrapperRef, activeIndex, overallProgress, jumpTo } = useScrollSections(ZONE_COUNT);

  return (
    <Background>
      <Header name={data.profile.name} nav={data.nav} activeIndex={activeIndex} onNavigate={jumpTo} />

      <div ref={wrapperRef} style={{ height: `${ZONE_COUNT * 100}vh` }}>
        <div
          className="sticky flex flex-col justify-center px-3 sm:px-6 xl:px-10"
          style={{ top: theme.headerHeight, height: `calc(100vh - ${theme.headerHeight}px)` }}
        >
          <div className="mx-auto flex w-full max-w-[1280px] items-stretch gap-2 sm:gap-4 lg:gap-6">
            <Rail nav={data.nav} profile={data.profile} activeIndex={activeIndex} onNavigate={jumpTo} />

            <div
              className="min-h-[500px] flex-1 rounded-xl border p-5 sm:p-8 xl:p-12 flex flex-col justify-center overflow-hidden"
              style={{ background: theme.surface, borderColor: theme.border }}
            >
              {activeIndex === 0 && (
                <SummaryPage profile={data.profile} projects={data.projects} contact={data.contact} onMoreAboutMe={() => jumpTo(1)} />
              )}
              {activeIndex === 1 && <AboutPage about={data.about} />}
              {activeIndex === 2 && <ProjectsPage projects={data.projects} />}
              {activeIndex === 3 && <SkillsPage skillGroups={data.skillGroups} />}
              {activeIndex === 4 && <ContactPage contact={data.contact} />}
            </div>
          </div>

          <ProgressBar progress={overallProgress} />
        </div>
      </div>

      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </Background>
  );
}
