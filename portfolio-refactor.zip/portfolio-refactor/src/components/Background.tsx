import type { ReactNode } from "react";
import { theme } from "../theme/theme";

/**
 * Background.tsx
 *
 * Everything about the site-wide background lives here. Today it's a flat
 * GitHub-dark fill. If this changes later (gradient, subtle grid pattern,
 * an image, etc.), this is the only file that needs editing — no other
 * component depends on how the background is implemented.
 */
export default function Background({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen" style={{ background: theme.bg, color: theme.text }}>
      {children}
    </div>
  );
}
