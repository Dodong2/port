import { theme } from "../theme/theme";
import type { NavItem } from "../types";

interface HeaderProps {
  name: string;
  nav: NavItem[];
  activeIndex: number;
  onNavigate: (zone: number) => void;
}

/**
 * Flat nav links laid out on the right — no hamburger/dropdown at any
 * breakpoint. Labels shrink on small screens instead of collapsing into
 * a menu.
 */
export default function Header({ name, nav, activeIndex, onNavigate }: HeaderProps) {
  return (
    <header
      className="sticky top-0 z-50 flex items-center justify-between border-b px-4 sm:px-8"
      style={{ background: theme.surface, borderColor: theme.border, height: theme.headerHeight }}
    >
      <span className="shrink-0 font-mono text-sm sm:text-base font-semibold tracking-tight" style={{ color: theme.textStrong }}>
        {name
          .split(" ")
          .map((w) => w[0])
          .join("")
          .toUpperCase()}
      </span>

      <nav className="flex items-center gap-3 sm:gap-6 overflow-x-auto">
        {nav.map((item, index) => {
          const isActive = activeIndex === index;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onNavigate(index)}
              className="relative shrink-0 whitespace-nowrap text-xs sm:text-sm transition-colors"
              style={{ color: isActive ? theme.textStrong : theme.muted }}
            >
              {item.label}
              <span
                className="absolute -bottom-2 left-0 right-0 h-[2px] rounded-full transition-opacity"
                style={{ background: theme.accentHover, opacity: isActive ? 1 : 0 }}
              />
            </button>
          );
        })}
      </nav>
    </header>
  );
}
