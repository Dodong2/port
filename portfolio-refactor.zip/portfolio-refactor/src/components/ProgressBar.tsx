import { theme } from "../theme/theme";

/** progress: 0–1, continuous across the whole scroll journey (not per page). */
export default function ProgressBar({ progress }: { progress: number }) {
  return (
    <div className="mx-auto mt-4 w-full max-w-[1280px] px-4 sm:px-6 xl:px-10">
      <div className="h-1.5 overflow-hidden rounded-full" style={{ background: theme.border }}>
        <div
          className="h-full rounded-full transition-[width] duration-150"
          style={{ width: `${progress * 100}%`, background: theme.accentHover }}
        />
      </div>
    </div>
  );
}
