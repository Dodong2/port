import { theme } from "../theme/theme";
import type { Project } from "../types";

export default function ProjectRow({ project }: { project: Project }) {
  return (
    <div
      className="flex items-center justify-between gap-4 rounded-lg border px-4 py-3"
      style={{ background: theme.inset, borderColor: theme.border }}
    >
      <span className="min-w-0 truncate text-sm sm:text-base" style={{ color: theme.text }}>
        {project.title}
      </span>
      <span className="shrink-0 rounded-full px-2 py-1 text-xs font-mono" style={{ background: theme.accentSoft, color: theme.accentHover }}>
        {project.status}
      </span>
    </div>
  );
}
