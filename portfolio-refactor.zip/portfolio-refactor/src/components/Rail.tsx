import type { IconType } from "react-icons";
import { FaHome, FaUserAlt } from "react-icons/fa";
import { LuFolderGit2 } from "react-icons/lu";
import { IoTerminal } from "react-icons/io5";
import { BiLogoGmail } from "react-icons/bi";
import RailNode from "./RailNode";
import type { NavItem, ProfileInfo } from "../types";

interface RailProps {
  nav: NavItem[];
  profile: ProfileInfo;
  activeIndex: number;
  onNavigate: (zone: number) => void;
}

// Icons for every nav id except "summary" (that one gets the avatar/home treatment)
const ICONS: Record<string, IconType> = {
  about: FaUserAlt,
  projects: LuFolderGit2,
  skills: IoTerminal,
  contact: BiLogoGmail,
};

/**
 * On large screens: first node is a big photo avatar, rest are small icons.
 * On mobile: EVERY node is small (including the first, which swaps its
 * photo for a Home icon) so the rail eats as little width as possible and
 * the content card can take up almost the full page.
 */
export default function Rail({ nav, profile, activeIndex, onNavigate }: RailProps) {
  const [heroItem, ...restItems] = nav;

  return (
    <aside
      className="flex shrink-0 flex-col items-center justify-between py-3 w-10 lg:w-24 lg:py-4"
      aria-label="Portfolio sections"
    >
      <RailNode
        active={activeIndex === 0}
        onClick={() => onNavigate(0)}
        label={`Go to ${heroItem.label}`}
        sizeClassName="w-9 h-9 lg:w-[88px] lg:h-[88px]"
      >
        {/* Mobile: home icon. Desktop: actual photo. Replace the src below. */}
        <FaHome size={15} className="lg:hidden" />
        <img
          src={profile.avatar}
          alt={profile.name}
          className="hidden h-full w-full object-cover lg:block"
          onError={(e) => {
            // Falls back to a neutral placeholder if avatar.jpg hasn't been added yet.
            e.currentTarget.src = "https://placehold.co/180x180/161B22/8B949E?text=Photo";
          }}
        />
      </RailNode>

      {restItems.map((item, i) => {
        const zone = i + 1;
        const Icon = ICONS[item.id] ?? FaUserAlt;
        return (
          <RailNode
            key={item.id}
            active={activeIndex === zone}
            onClick={() => onNavigate(zone)}
            label={`Go to ${item.label}`}
            sizeClassName="w-9 h-9 lg:w-11 lg:h-11"
          >
            <Icon size={15} />
          </RailNode>
        );
      })}
    </aside>
  );
}
