import type { ReactNode } from "react";
import { theme } from "../theme/theme";

interface RailNodeProps {
  active: boolean;
  onClick: () => void;
  label: string;
  /** Tailwind size classes, e.g. "w-9 h-9 lg:w-11 lg:h-11" */
  sizeClassName: string;
  children: ReactNode;
}

/**
 * One circle on the rail. Renders its own short connector line to the
 * content card — the line only appears (width/opacity animate in) while
 * this node is the active one. Inactive nodes show no line at all.
 */
export default function RailNode({ active, onClick, label, sizeClassName, children }: RailNodeProps) {
  return (
    <div className="relative flex items-center">
      <button
        type="button"
        onClick={onClick}
        aria-label={label}
        className={`relative flex items-center justify-center overflow-hidden rounded-full border-2 transition-colors duration-300 focus:outline-none focus-visible:ring-4 focus-visible:ring-[#58A6FF]/40 ${sizeClassName}`}
        style={{
          background: active ? theme.accentSoft : theme.inset,
          borderColor: active ? theme.accentHover : theme.border,
          color: active ? theme.accentHover : theme.muted,
        }}
      >
        {children}
      </button>

      <div
        className="pointer-events-none absolute top-1/2 left-full h-px -translate-y-1/2 transition-all duration-300 ease-out"
        style={{
          width: active ? theme.connectorLength : 0,
          opacity: active ? 1 : 0,
          background: theme.accentHover,
        }}
      />
    </div>
  );
}
