import type { ReactNode } from "react";
import { theme } from "../theme/theme";

interface SocialButtonProps {
  href: string;
  label: string;
  children: ReactNode;
}

export default function SocialButton({ href, label, children }: SocialButtonProps) {
  return (
    <a
      href={href}
      target={href !== "#" ? "_blank" : undefined}
      rel={href !== "#" ? "noreferrer" : undefined}
      className="inline-flex items-center gap-2 rounded-md border px-4 py-2 text-sm transition-colors"
      style={{ borderColor: theme.border, color: theme.link }}
      aria-label={label}
    >
      {children}
      {label}
    </a>
  );
}
