import { theme } from "../../theme/theme";
import type { AboutInfo } from "../../types";

export default function AboutPage({ about }: { about: AboutInfo }) {
  return (
    <div className="min-h-[440px] animate-[fadeIn_0.4s_ease] overflow-y-auto">
      <p className="mb-2 font-mono text-xs" style={{ color: theme.muted }}>
        01 · about
      </p>
      <h2 className="mb-4 text-2xl sm:text-3xl font-normal" style={{ color: theme.textStrong }}>
        Who I am
      </h2>
      <p className="max-w-2xl leading-relaxed" style={{ color: theme.muted }}>
        {about.bio}
      </p>

      <div className="mt-8 grid gap-10 sm:grid-cols-2">
        <div>
          <p className="mb-3 text-sm font-medium" style={{ color: theme.textStrong }}>
            Education
          </p>
          <div className="rounded-md border px-5 py-4 text-sm leading-relaxed" style={{ background: theme.inset, borderColor: theme.border }}>
            <p className="font-medium" style={{ color: theme.textStrong }}>{about.education.school}</p>
            <p style={{ color: theme.muted }}>{about.education.program}</p>
            <p style={{ color: theme.muted }}>{about.education.years}</p>
            <p className="mt-2" style={{ color: theme.accentHover }}>🏆 {about.education.award}</p>
          </div>
        </div>

        <div>
          <p className="mb-3 text-sm font-medium" style={{ color: theme.textStrong }}>
            Experience
          </p>
          <div className="space-y-3">
            {about.experience.map((job) => (
              <div key={job.company + job.role} className="rounded-md border px-4 py-3 text-sm" style={{ background: theme.inset, borderColor: theme.border }}>
                <div className="flex items-baseline justify-between gap-3">
                  <p className="font-medium" style={{ color: theme.textStrong }}>{job.role}</p>
                  <span className="shrink-0 font-mono text-xs" style={{ color: theme.muted }}>{job.period}</span>
                </div>
                <p className="mt-0.5" style={{ color: theme.accentHover }}>{job.company}</p>
                <ul className="mt-2 list-disc space-y-1 pl-4" style={{ color: theme.muted }}>
                  {job.points.map((point) => (
                    <li key={point}>{point}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
