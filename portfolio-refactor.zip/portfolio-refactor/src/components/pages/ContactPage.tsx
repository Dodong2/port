import { theme } from "../../theme/theme";
import type { ContactInfo } from "../../types";

export default function ContactPage({ contact }: { contact: ContactInfo }) {
  return (
    <div className="flex min-h-[440px] flex-col justify-center animate-[fadeIn_0.4s_ease]">
      <p className="mb-2 font-mono text-xs" style={{ color: theme.muted }}>
        04 · contact
      </p>
      <h2 className="mb-6 text-2xl sm:text-3xl font-normal" style={{ color: theme.textStrong }}>
        Let's work together
      </h2>
      <div className="grid gap-8 sm:grid-cols-2">
        <div>
          <p className="mb-2 text-sm font-medium" style={{ color: theme.textStrong }}>Reach me</p>
          <div className="space-y-2 text-sm">
            <a href={`mailto:${contact.email}`} className="block rounded-md border px-4 py-2.5" style={{ background: theme.inset, borderColor: theme.border, color: theme.link }}>
              {contact.email}
            </a>
            <a href={`tel:${contact.phone}`} className="block rounded-md border px-4 py-2.5" style={{ background: theme.inset, borderColor: theme.border, color: theme.link }}>
              {contact.phone}
            </a>
            <a href={contact.portfolio} target="_blank" rel="noreferrer" className="block rounded-md border px-4 py-2.5" style={{ background: theme.inset, borderColor: theme.border, color: theme.link }}>
              {contact.portfolio.replace("https://", "")}
            </a>
          </div>
        </div>

        <div>
          <p className="mb-2 text-sm font-medium" style={{ color: theme.textStrong }}>Work location & availability</p>
          <p className="rounded-md border px-4 py-3 text-sm leading-relaxed" style={{ background: theme.inset, borderColor: theme.border, color: theme.muted }}>
            {contact.workLocation}
          </p>
        </div>
      </div>
    </div>
  );
}
