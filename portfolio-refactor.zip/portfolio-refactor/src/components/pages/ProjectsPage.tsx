import { theme } from "../../theme/theme";
import type { Project } from "../../types";

export default function ProjectsPage({ projects }: { projects: Project[] }) {
  return (
    <div className="flex min-h-[440px] flex-col justify-center animate-[fadeIn_0.4s_ease]">
      <p className="mb-2 font-mono text-xs" style={{ color: theme.muted }}>
        02 · projects
      </p>
      <h2 className="mb-6 text-2xl sm:text-3xl font-normal" style={{ color: theme.textStrong }}>
        Selected work
      </h2>
      <div className="grid gap-4 sm:grid-cols-2">
        {projects.map((project) => (
          <div key={project.title} className="rounded-lg border p-5" style={{ background: theme.inset, borderColor: theme.border }}>
            <p className="mb-1 font-medium" style={{ color: theme.textStrong }}>{project.title}</p>
            <p className="mb-4 text-sm" style={{ color: theme.muted }}>{project.desc}</p>
            <span className="rounded-full px-2 py-1 text-xs font-mono" style={{ background: theme.accentSoft, color: theme.accentHover }}>
              {project.status}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
