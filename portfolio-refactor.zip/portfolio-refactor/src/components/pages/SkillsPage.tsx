import { theme } from "../../theme/theme";
import type { SkillGroup } from "../../types";

export default function SkillsPage({ skillGroups }: { skillGroups: SkillGroup[] }) {
  return (
    <div className="flex min-h-[440px] flex-col justify-center animate-[fadeIn_0.4s_ease]">
      <p className="mb-2 font-mono text-xs" style={{ color: theme.muted }}>
        03 · skills
      </p>
      <h2 className="mb-6 text-2xl sm:text-3xl font-normal" style={{ color: theme.textStrong }}>
        What I work with
      </h2>
      <div className="grid gap-x-8 gap-y-6 sm:grid-cols-2">
        {skillGroups.map((group) => (
          <div key={group.label}>
            <p className="mb-2 text-sm font-medium" style={{ color: theme.textStrong }}>{group.label}</p>
            <div className="flex flex-wrap gap-2">
              {group.items.map((skill) => (
                <span
                  key={skill}
                  className="rounded-md border px-3 py-1 font-mono text-xs"
                  style={{ borderColor: theme.border, background: theme.inset, color: theme.text }}
                >
                  {skill}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
