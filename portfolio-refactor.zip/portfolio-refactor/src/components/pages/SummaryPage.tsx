import { theme } from "../../theme/theme";
import ProjectRow from "../ProjectRow";
import SocialButton from "../SocialButton";
import { FaGithub, FaLinkedin, FaFacebook } from "react-icons/fa";
import type { ProfileInfo, Project, ContactInfo } from "../../types";

interface SummaryPageProps {
  profile: ProfileInfo;
  projects: Project[];
  contact: ContactInfo;
  onMoreAboutMe: () => void;
}

export default function SummaryPage({ profile, projects, contact, onMoreAboutMe }: SummaryPageProps) {
  return (
    <div className="grid min-h-[440px] grid-cols-1 gap-10 xl:grid-cols-[1.05fr_0.95fr] animate-[fadeIn_0.4s_ease]">
      <div className="flex flex-col justify-center">
        <p className="mb-2 text-sm" style={{ color: theme.muted }}>
          {profile.tagline}
        </p>
        <h1 className="max-w-[540px] text-3xl sm:text-4xl xl:text-5xl font-normal leading-[1.1]" style={{ color: theme.textStrong }}>
          {profile.headline}
        </h1>
        <p className="mt-6 max-w-[540px] leading-relaxed" style={{ color: theme.muted }}>
          {profile.shortBio}
        </p>
      </div>

      <div className="pt-1">
        <p className="mb-3 font-mono text-xs" style={{ color: theme.muted }}>
          recent project
        </p>
        <div className="space-y-3">
          {projects.slice(0, 2).map((p) => (
            <ProjectRow key={p.title} project={p} />
          ))}
        </div>

        <div className="mt-8 flex flex-wrap gap-3">
          <SocialButton href={contact.socials.github} label="GitHub">
            <FaGithub size={15} />
          </SocialButton>
          <SocialButton href={contact.socials.linkedin} label="LinkedIn">
            <FaLinkedin size={15} />
          </SocialButton>
          <SocialButton href={contact.socials.facebook} label="Facebook">
            <FaFacebook size={15} />
          </SocialButton>
        </div>

        <button
          type="button"
          onClick={onMoreAboutMe}
          className="mt-5 rounded-md px-6 py-2.5 text-sm font-medium text-white transition-colors"
          style={{ background: theme.accent }}
          onMouseEnter={(e) => (e.currentTarget.style.background = theme.accentHover)}
          onMouseLeave={(e) => (e.currentTarget.style.background = theme.accent)}
        >
          More about me
        </button>
      </div>
    </div>
  );
}
