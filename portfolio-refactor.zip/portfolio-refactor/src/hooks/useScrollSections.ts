import { useEffect, useRef, useState } from "react";

interface UseScrollSectionsResult {
  wrapperRef: React.RefObject<HTMLDivElement>;
  activeIndex: number;
  /** 0–1, continuous across ALL zones — never resets when moving to a new page. */
  overallProgress: number;
  jumpTo: (zone: number) => void;
}

/**
 * Tracks scroll position inside a tall "pinned" wrapper and derives:
 * - which zone (page) is currently active
 * - overall progress (0–1) across the whole scroll journey, continuous
 *
 * Runs on all screen sizes — the same pinned/sticky pattern is now used
 * on mobile too (just with a smaller rail), not a separate stacked layout.
 */
export function useScrollSections(zoneCount: number): UseScrollSectionsResult {
  const wrapperRef = useRef<HTMLDivElement>(null);
  const [activeIndex, setActiveIndex] = useState(0);
  const [overallProgress, setOverallProgress] = useState(0);

  useEffect(() => {
    const onScroll = () => {
      const wrapper = wrapperRef.current;
      if (!wrapper) return;

      const rect = wrapper.getBoundingClientRect();
      const total = rect.height - window.innerHeight;
      if (total <= 0) return;

      const scrolled = Math.max(0, Math.min(-rect.top, total));
      const overall = scrolled / total; // continuous 0–1, never resets per zone
      const zonePosition = overall * zoneCount;
      const index = Math.min(zoneCount - 1, Math.floor(zonePosition));

      setActiveIndex(index);
      setOverallProgress(overall);
    };

    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    onScroll();

    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
    };
  }, [zoneCount]);

  const jumpTo = (zone: number) => {
    const wrapper = wrapperRef.current;
    if (!wrapper) return;

    const wrapperTop = wrapper.getBoundingClientRect().top + window.scrollY;
    const total = wrapper.offsetHeight - window.innerHeight;
    const target = wrapperTop + (zone / zoneCount) * total + 2;
    window.scrollTo({ top: target, behavior: "smooth" });
  };

  return { wrapperRef, activeIndex, overallProgress, jumpTo };
}
