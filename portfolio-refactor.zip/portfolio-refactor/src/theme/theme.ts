/**
 * theme.ts
 *
 * All color/spacing tokens live here, in one place. If the palette ever
 * changes (not just GitHub-dark, but a full re-brand), this is the only
 * file that needs to change — components read from `theme`, they never
 * hardcode hex values themselves.
 */

export const theme = {
  // GitHub dark mode palette
  bg: "#0D1117",
  surface: "#161B22",
  inset: "#010409",
  border: "#30363D",
  text: "#C9D1D9",
  textStrong: "#E6EDF3",
  muted: "#8B949E",
  accent: "#238636",
  accentHover: "#2EA043",
  accentSoft: "rgba(46,160,67,0.15)",
  link: "#58A6FF",

  // Layout
  headerHeight: 64, // px
  connectorLength: 24, // px — length of the "active node -> card" line
} as const;

export type Theme = typeof theme;
