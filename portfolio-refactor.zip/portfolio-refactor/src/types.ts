export type ProjectStatus = "Live" | "Deployed" | "Completed" | "Delivered";

export interface Project {
  title: string;
  desc: string;
  status: ProjectStatus;
}

export interface SkillGroup {
  label: string;
  items: string[];
}

export interface ExperienceItem {
  company: string;
  role: string;
  period: string;
  points: string[];
}

export interface EducationInfo {
  school: string;
  program: string;
  years: string;
  award: string;
}

export interface AboutInfo {
  bio: string;
  education: EducationInfo;
  experience: ExperienceItem[];
}

export interface ProfileInfo {
  name: string;
  tagline: string;
  headline: string;
  shortBio: string;
  avatar: string;
}

export interface ContactInfo {
  email: string;
  phone: string;
  portfolio: string;
  socials: {
    github: string;
    linkedin: string;
    facebook: string;
  };
  workLocation: string;
}

export interface NavItem {
  id: string;
  label: string;
}

export interface ContentData {
  nav: NavItem[];
  profile: ProfileInfo;
  about: AboutInfo;
  projects: Project[];
  skillGroups: SkillGroup[];
  contact: ContactInfo;
}
